var r = 0;
var g = 0;
var b = 0;
var a = 0;
var error = 0;

function drawdata(){
    if(boolland){
        drawlandscape();
    }
    if(boolpointing){
        drawpointingError();
    }
    drawpointingKey();
    if(boolicon){
        drawicon();
    }
    if(booltrajec){
        drawtrajectories();
    }
    
}


function drawlandscape(){
    strokeWeight(4);
    for (i = 0; i<mapRows;i++){
        for(j = 0; j<mapCols; j++){
            if(landscape[i][j].y!=0){
                push();
                r = map(landscape[i][j].y,-mapmin,-mapmax*0.13,colorcurrent.r[0],colorcurrent.r[1]);
                g = map(landscape[i][j].y,-mapmin,-mapmax*0.13,colorcurrent.g[0],colorcurrent.g[1]);
                b = map(landscape[i][j].y,-mapmin,-mapmax*0.13,colorcurrent.b[0],colorcurrent.b[1]);
                a = map(landscape[i][j].y,-mapmin,-mapmax*0.05,colorcurrent.a[0],colorcurrent.a[1]);
                stroke(color(r,g,b,a));
                translate(landscape[i][j].x,landscape[i][j].y,landscape[i][j].z);
                point(0,0,0);
                pop();
            }
        }
    }
}

function drawpointingError(){
    for (i=0;i<performRows;i++){
        if(pointingmatrix[i][3]<=0){
            if(abs(pointingmatrix[i][3])<=180){
                error=abs(pointingmatrix[i][3]);
            }else{error=360+pointingmatrix[i][3];}
        }else{
            if(pointingmatrix[i][3]<=180){
                error=pointingmatrix[i][3];}else{
                    error=360-pointingmatrix[i][3];
                }
        }
        if(error<=errorslider.value()){
            if(booltriallist[pointingmatrix[i][17]]){
                push();
                strokeWeight(1);
                translate(pointingscale[i].x1,0,pointingscale[i].z1)
                rotate(pointingmatrix[i][3]*PI/180.0,[0,-1,0]);
                r = map(pointingmatrix[i][0],1,27,160,255);
                g = map(abs(pointingmatrix[i][0]-14),0,13,80,255);
                b = map(pointingmatrix[i][0],27,1,110,255);
                a = map(error,0,180,pointingslider.value(),10);
                beginShape();
                stroke(color(r, g, b, a));
                noFill();
                vertex(0,0,0);// start point
                bezierVertex(0,pointingscale[i].d,0, pointingscale[i].x2-pointingscale[i].x1,pointingscale[i].d,pointingscale[i].z2-pointingscale[i].z1, pointingscale[i].x2-pointingscale[i].x1,0,pointingscale[i].z2-pointingscale[i].z1); //control point 1, control point 2, end point
                endShape();
                strokeWeight(5);
                stroke(color(r,g,b,a));
                point(pointingscale[i].x2-pointingscale[i].x1,0,pointingscale[i].z2-pointingscale[i].z1);
                pop();
            }
            
        }
    }
    
}

function drawpointingKey(){
    strokeWeight(2);
    for (i=0;i<trialRows;i++){
        if(booltriallist[i]){
            push();
            translate(trialscale[i].x1,0,trialscale[i].z1);
            r = map(trialmatrix[i][4],1,27,160,255);
            g = map(abs(trialmatrix[i][4]-14),0,13,80,255);
            b = map(trialmatrix[i][4],27,1,110,255);
            beginShape();
            c = color(r, g, b);
            stroke(c);
            noFill();
            vertex(0,0,0);// start point
            bezierVertex(0,trialscale[i].d,0, trialscale[i].x2-trialscale[i].x1,trialscale[i].d,trialscale[i].z2-trialscale[i].z1, trialscale[i].x2-trialscale[i].x1,0,trialscale[i].z2-trialscale[i].z1); //control point 1, control point 2, end point
            endShape();
            pop();
        }
        
    }
}

function drawicon(){
    for(i = 0; i<12; i++){
        push();
        translate(iconlocation[i].x,-mapmax*0.12/2,iconlocation[i].z);
        ambientMaterial(255);
        texture(icon[i]);
        noStroke();
        plane(50);
        pop();
    }
}

function drawtrajectories(){
    strokeWeight(4);
    for(j=0;j<3;j++){
        for (i = 0; i<trajecRows[0];i++){
            if((i<radians(angle3)*trajecRows[j]/PI)&&(i>radians(angle3-15)*trajecRows[j]/PI)){
                push();
                a = map(i,radians(angle3-15)*trajecRows[j]/PI,radians(angle3)*trajecRows[j]/PI,0,150);
                r = 255;
                g = 255;
                b = 255;
                stroke(color(r,g,b,a));
                translate(trajecScale[j][i].x,-mapmax*0.12/2,trajecScale[j][i].z);
                point(0,0,0);
                pop();
            }   
        }
    }
    
}
