var xtop = 0, ztop =0,xtarget =0,ztarget = 0,dis = 0;

function readdata(){
    readlandscape();
    readpointingdata();
    readtrialfeatures();
    readtrajecdata();
}

function readlandscape(){
    //Read landscape(3D heatmap) data
    mapRows = maptable.getRowCount();
    mapCols = maptable.getColumnCount();
    print("LandscapeRows: " + mapRows + " , LandscapeColumns: " + mapCols); 
    for (var i=0; i<mapRows; i++){
        mapmatrix[i]=[];
        for(j=0;j<mapCols;j++){
            if(maptable.getNum(i,j)>9){
                mapmatrix[i][j]=Math.log(maptable.getNum(i,j));
            }else{
                mapmatrix[i][j]=maptable.getNum(i,j);
            }
                
            //print(mapmatrix[i][j]);
        }
    }
    
    //find range for the landscape
    for (i=0; i<mapRows;i++){
        for(j=0;j<mapCols;j++){
            if(mapmatrix[i][j]<mapymin){
                mapymin=mapmatrix[i][j];
            }
            if(mapmatrix[i][j]>mapymax){
                mapymax=mapmatrix[i][j];
            }
        }
    }
    print("mapymin: " + mapymin + " , mapymax: " + mapymax);
    
    //map data to the canvas
    for (i=0;i<mapRows;i++){
        landscape[i]=[];
        for(j=0;j<mapCols;j++){
            var xPos = map(i,0,mapRows,-mapmax,mapmax);
            var yPos = map(mapmatrix[i][j],mapymin,mapymax,-mapmin,-mapmax*0.3);
            var zPos = map(-j,-mapCols,0,-mapmax,mapmax);
            landscape[i][j]={x: xPos,y:yPos,z:zPos};
            //print(landscape[i][j].x);
        }
    }
}

function readpointingdata(){
    //Read Performance Data
    //Get the number of rows of the data
    performRows= pointingtable.getRowCount();
    //Get the number of columns of the data
    performCols= pointingtable.getColumnCount(); 
    print("Rows: " + performRows + " , Columns: " + performCols);  
    
    // retrieve data from table
    for(var i = 0; i <performRows; i++){
        pointingmatrix[i]= []; //create nested array
        for(var j = 0; j < performCols; j++){
            if(j==10 || j==12){
                pointingmatrix[i][j]=pointingtable.get(i,j)-6;
            }else if(j==11 || j==13){
                pointingmatrix[i][j]=pointingtable.get(i,j)-5;
            }else{
                pointingmatrix[i][j]=pointingtable.get(i,j);
            }
            //print(pointingmatrix[i][j]);
        }
    }
    
    // map coordinates to the scale of the canvas
    for (i=0;i<performRows;i++){
        xtop = map(pointingmatrix[i][10],0,mapRows,-mapmax,mapmax);
        ztop = map(-pointingmatrix[i][11],-mapCols,0,-mapmax,mapmax);
        xtarget = map(pointingmatrix[i][12],0,mapRows,-mapmax,mapmax);
        ztarget = map(-pointingmatrix[i][13],-mapCols,0,-mapmax,mapmax);
        dis = map(pointingmatrix[i][14],0,(mapRows+mapCols)/2,0,mapmax);
        pointingscale[i]={x1: xtop,z1:ztop,x2:xtarget,z2:ztarget,d:-dis};
    }
    
}

function readtrialfeatures(){
    //Read Trial features
    //Get the number of rows of the data
    trialRows= trialtable.getRowCount();
    //Get the number of columns of the data
    trialCols= trialtable.getColumnCount(); 
    print("Rows: " + trialRows + " , Columns: " + trialCols);  
    
    // retrieve data from table
    for(i = 0; i <trialRows; i++){
        trialmatrix[i]= []; //create nested array
        for(j = 0; j < trialCols; j++){
            if(j==5 || j==7){
                trialmatrix[i][j]=trialtable.get(i,j)-6;
            }else if(j==6 || j==8){
                trialmatrix[i][j]=trialtable.get(i,j)-5;
            }else{
                trialmatrix[i][j]=trialtable.get(i,j);
            }
            //print(pointingmatrix[i][j]);
        }
    }
    // map coordinates to the scale of the canvas
    for (i=0;i<trialRows;i++){
        xtop = map(trialmatrix[i][5],0,mapRows,-mapmax,mapmax);
        ztop = map(-trialmatrix[i][6],-mapCols,0,-mapmax,mapmax);
        xtarget = map(trialmatrix[i][7],0,mapRows,-mapmax,mapmax);
        ztarget = map(-trialmatrix[i][8],-mapCols,0,-mapmax,mapmax);
        dis = map(trialmatrix[i][9],0,(mapRows+mapCols)/2,0,mapmax);
        trialscale[i]={x1: xtop,z1:ztop,x2:xtarget,z2:ztarget,d:-dis};
    }
    
    //read icon location
    iconlocation[0]={x:trialscale[0].x1,z: trialscale[0].z1};
    //print(iconlocation[0].x);
    var j=1
    for (i=1;i<trialRows;i++){
        if(trialmatrix[i][0]!=trialmatrix[i-1][0]){
            iconlocation[j] = {x: trialscale[i].x1, z: trialscale[i].z1};
            //print(iconlocation[j].x);
            j++;
        }
    }
    
}

function readtrajecdata(){
    //Read trajectory data
    for(i=0;i<3;i++){
        trajecRows[i] = trajectable[i].getRowCount();
        trajecCols[i] = trajectable[i].getColumnCount();
        trajecmatrix[i]=[];
        print("TrajectRows: "+ trajecRows[i]+ " , TrajecColumns: " + trajecCols[i]);
        for (j=0; j<trajecRows[i]; j++){
            trajecmatrix[i][j]=[];
            for(k=0; k<trajecCols[i]; k++){
                if(k==4){
                    trajecmatrix[i][j][k]=trajectable[i].get(j,k)-6;
                }else if(k==5){
                    trajecmatrix[i][j][k]=trajectable[i].get(j,k)-5;
                }else{
                    trajecmatrix[i][j][k]=trajectable[i].get(j,k);
                }
            }
        }
        //map trajectory data to the scale of the canvas
        trajecScale[i]=[];
        for (j=0;j<trajecRows[i];j++){
            xtop = map(trajecmatrix[i][j][4],0,mapRows,-mapmax,mapmax);
            ztop = map(-trajecmatrix[i][j][5],-mapCols,0,-mapmax,mapmax);
            //print(xtop);
            trajecScale[i][j]={x:xtop,z:ztop};
            //print(trajecScale[i][j].x);
        }
    }
    
    
}