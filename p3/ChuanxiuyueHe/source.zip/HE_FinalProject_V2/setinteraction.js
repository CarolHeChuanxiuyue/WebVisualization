function setInteraction(){
    mapsel.changed(mapSelectEvent);
    
    ////map color solution
    buttonmapcolor = createButton('change heatmap colors');
    buttonmapcolor.style('background-color',color(255,255,255,200));
    buttonmapcolor.style('color',color(0,0,15));
    buttonmapcolor.style('font-size','60%');
    buttonmapcolor.style('font-family','Arial');
    buttonmapcolor.position(2*cellsize,mapmax-cellsize/2);
    buttonmapcolor.mousePressed(selectMapColor);
    
    //Interactivity0: show landscape or not
    checklandscape = createCheckbox('Navigation Heatmap',false);
    checklandscape.position(cellsize,mapmax-5*cellsize/2);
    checklandscape.style('color',color(200,255,255,200));
    checklandscape.style('font-family','Arial');
    checklandscape.changed(drawland);
    
    //Interactivity1: autorotation or not
    checkrotate = createCheckbox('Autorotation',true);
    checkrotate.position(cellsize,mapmax-11*cellsize/2);
    checkrotate.style('color',color(255,255,200,200));
    checkrotate.style('font-family','Arial');
    checkrotate.changed(drawrotate);
    
    //Interactivity2: show icon or not
    checkicon = createCheckbox('Landmark Icon',true);
    checkicon.position(cellsize,mapmax-9*cellsize/2);
    checkicon.style('color',color(255,255,200,200));
    checkicon.style('font-family','Arial');
    checkicon.changed(drawiconjudge);
    
    //Interactivity3: show trajectories or not
    checktrajec = createCheckbox('Sample Trajectories',true);
    checktrajec.position(cellsize,mapmax-7*cellsize/2);
    checktrajec.style('color',color(255,255,200,200));
    checktrajec.style('font-family','Arial');
    checktrajec.changed(drawtrajec);
    
    
    //Interactivity4: show pointing error or not
    checkpointing = createCheckbox('Pointing',false);
    checkpointing.position(cellsize,mapmax+cellsize/2);
    checkpointing.style('color',color(255,200,255,200));
    checkpointing.style('font-family','Arial');
    checkpointing.changed(drawpointingerror);
    
    //Interactivity5: transparency of the pointing error
    pointingslider = createSlider(20,255,50);
    pointingslider.position(cellsize,mapmax+3*cellsize/2);
    pointingslider.mouseOver(overpointing);
    pointingslider.mouseOut(outpointing);
    sliderlabel1 = createP('Saturation');
    sliderlabel1.mouseOver(overpointing);
    sliderlabel1.mouseOut(outpointing);
    sliderlabel1.position(pointingslider.x * 1.5 + pointingslider.width, pointingslider.y-0.4*cellsize);
    sliderlabel1.style('color',color(255,255,255,200));
    sliderlabel1.style('font-size','80%');
    sliderlabel1.style('font-family','Arial');
    
    //Interactivity6: range of the pointing error shown on the canvas
    errorslider = createSlider(0,180,180);
    errorslider.position(cellsize,mapmax+5*cellsize/2);
    sliderlabel2 = createP('Range');
    sliderlabel2.position(errorslider.x * 1.5 + errorslider.width, errorslider.y-0.4*cellsize);
    sliderlabel2.style('color',color(255,255,255,200));
    sliderlabel2.style('font-size','80%');
    sliderlabel2.style('font-family','Arial');
    
    
    //Interactivity7: select trials
    triallabel3 = createP('Trial List');
    triallabel3.position(cellsize, mapmax+3*cellsize);
    triallabel3.style('color',color(255,200,255,200));
    triallabel3.style('font-family','Arial');
    for(i = 0; i<trialRows;i++){
        booltriallist[i]=false;
        j=i+1;
        checktriallist[i] = createCheckbox(trialmatrix[i][0]+' to '+trialmatrix[i][1],false);
        checktriallist[i].position(cellsize,mapmax+4.5*cellsize+i*cellsize/2);
        checktriallist[i].style('color',color(255,200,255,200));
        checktriallist[i].style('font-family','Arial');
    }
    
    //Interactivity8: select/clear all trials
    buttontrial = createButton('Select/Clear All trials');
    buttontrial.style('background-color',color(255,200,255,200));
    buttontrial.style('color',color(0,0,15));
    buttontrial.position(cellsize,mapmax+15*cellsize);
    buttontrial.style('font-family','Arial');
    buttontrial.mousePressed(selectalltrial);

    Title = createP('Maze Learning Performance <br/> People learn the maze by following a fixed route for five times. Here are 55 participants\' post-learning performance');
    Title.position(cellsize,cellsize/2);
    Title.style('color',color(100));
    Title.style('font-family','Arial');
    
    
    
}

function drawpointingerror(){
    if(boolpointing){
        boolpointing=false;
    }else{boolpointing=true;}
}

function drawland(){
    if(boolland){
        boolland=false;
    }else{boolland=true;}
}

function drawiconjudge(){
    if(boolicon){
        boolicon=false;
    }else{boolicon=true;}
}

function drawtrajec(){
    if(booltrajec){
        booltrajec=false;
    }else{booltrajec=true;}
}

function drawrotate(){
    if(boolrotate){
        boolrotate=false;
    }else{boolrotate=true;}
}

function selecttrial(){
    for(i = 0; i<trialRows;i++){
        if(checktriallist[i].checked()){
            booltriallist[i]=true;
        }else{booltriallist[i]=false;}
        //print(booltriallist[i]);
    }
}

function mapSelectEvent(){
    if(mapsel.value()=='female'){
        maptable=Femaletable;
        readlandscape();
    }else if(mapsel.value()=='male'){
        maptable=Maletable;
        readlandscape();
    }else{
        maptable=totaltable;
        readlandscape();
    }
}

function selectMapColor(){
    if(colorcurrent==colorpool[0]){
        colorcurrent=colorpool[1];
    }else if(colorcurrent==colorpool[1]){
        colorcurrent=colorpool[2];
    }else{colorcurrent=colorpool[0];}
    
}

function selectalltrial(){
    var selectedtrial = 0;
    for(i = 0; i<trialRows;i++){
        if(booltriallist[i]){
            selectedtrial++;
        }
    }
    if(selectedtrial<5){
        for(i=0;i<trialRows;i++){
            //checktriallist[i].removeAttribute('checked');
            checktriallist[i].attribute('checked',true);
            booltriallist[i]=true;
        }
    }else{
        for(i=0;i<trialRows;i++){
            checktriallist[i].removeAttribute('checked');
            booltriallist[i]=false;
            
        }
    }
}

function overpointing(){
    sliderlabel1.html('The differentiation of accuracy: <br/> more saturated indicates more accurate'); 
}

function outpointing(){
    sliderlabel1.html('Saturation'); 
}