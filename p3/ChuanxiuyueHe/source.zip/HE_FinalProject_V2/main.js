//load raw data
let maptable,totaltable,Femaletable,Maletable,pointingtable,trialtable,icon = [],trajectable = [];
let pointingmatrix = [],trialmatrix=[],mapmatrix = [],trajecmatrix=[];

let mapRows;
let mapCols;
let performRows;
let performCols;
let trialRows;
let trialCols;
let trajecRows=[];
let trajecCols=[];

//map raw data to the canvas
let mapmin=0,mapmax=250;
let mapymin=2*mapmax, mapymax=0;
let cellsize=mapmax/8;
let landscape = [],pointingscale = [],trialscale=[],iconlocation = [],trajecScale=[];

//animation
let angle1 = 0;
let angle3 = 0;


//interaction
////show icon or not
let checkicon;
let boolicon = true;
////show sample trajectory or not
let checktrajec;
let booltrajec = true;
////stop autorotation
let checkrotate;
let boolrotate = true;
////show landscape or not
let checklandscape;
let boolland = false;
////show pointing error or not
let checkpointing;
let boolpointing =false;
////alpha of the pointing error
let pointingslider;
let sliderlabel1;
////range of the pointing error shown
let errorslider;
let sliderlabel2;
////select trial
let triallabel3;
let checktriallist = [];
let booltriallist = [];
////select basemap
let mapsel;
let maplabel0;
////select color solution for 
let buttonmapcolor;
let colorpool = [
    {r: [10,210], g: [200,20], b: [100,20], a: [10,200]},
    {r: [118,216], g: [97,117], b: [131,102], a: [50,255]},
    {r: [50,61], g: [101,191], b: [117,189], a: [100,255]}
];
let colorcurrent=colorpool[0];
let buttontrial;

let Title

var i=0;
var j=0;



function preload(){
    pointingtable = loadTable("data/Pointingperformance.csv",'csv','header');
    totaltable = loadTable("data/3DHeatmap_landscape.csv",'csv','header');
    Femaletable = loadTable("data/Female_landscape.csv",'csv','header');
    Maletable = loadTable("data/Male_landscape.csv",'csv','header');
    trialtable = loadTable("data/trialfeature.csv",'csv','header');
    for(i = 0; i<3;i++){
        trajectable[i] = loadTable('data/test'+i+'.csv','csv','header');
    }
    //trajectable[1] = loadTable("data/test2.csv",'csv','header');
    icon[0] = loadImage("icon/well.png");
    icon[1] = loadImage("icon/chair.png");
    icon[2] = loadImage("icon/mailbox.png");
    icon[3] = loadImage("icon/telescope.png");
    icon[4] = loadImage("icon/plant.png");
    icon[5] = loadImage("icon/table.png");
    icon[6] = loadImage("icon/stove.png");
    icon[7] = loadImage("icon/piano.png");
    icon[8] = loadImage("icon/trashcan.png");
    icon[9] = loadImage("icon/bookshelf.png");
    icon[10] = loadImage("icon/wheelbarrow.png");
    icon[11] = loadImage("icon/harp.png");
    
    //textfont
    Arial = loadFont('Arial.ttf');
    
}

function setup(){
    //set up 3D canvas
    createCanvas(windowWidth,windowHeight,WEBGL);
    
    //Set of the starting perspective:perspective([fovy], [aspect], [near], [far])
    perspective(PI/3.0 , width / height, 0.1, 5000);
        
    ////map selection
    maplabel0 = createP('Heatmap List');
    maplabel0.position(5*cellsize, mapmax-1.8*cellsize);
    maplabel0.style('color',color(255,255,255,200));
    maplabel0.style('font-size','80%');
    maplabel0.style('font-family','Arial');
    mapsel = createSelect();
    mapsel.position(2*cellsize,mapmax-3*cellsize/2);
    mapsel.option('mixed');
    mapsel.option('female');
    mapsel.option('male');
    mapsel.selected('mixed');
    if(mapsel.value()=='female'){
        maptable=Femaletable;
    }else if(mapsel.value()=='male'){
        maptable=Maletable;
    }else{
        maptable=totaltable;
    }
    //Read Data and Map data to the scale of the canvas; 
    readdata();
    
    setInteraction();   
    
}

function draw(){
    //show buttons or not
    buttonvisibility();
    
    background(0);
    orbitControl();
    lights();
    
    rotate(45,[-1,1,0]);
    rotate(radians(angle1),[0,-1,0]);
    if(boolrotate){
        angle1=angle1+0.1;
    }
    angle3=angle3+1;
    if(angle3>180){angle3=0;}
    
    //pointLight(255,255,255,mouseX-5,mouseY-5,5);
    selecttrial();
    drawdata();

}

function buttonvisibility(){
    if(boolland){
        mapsel.show();
        maplabel0.show();
        buttonmapcolor.show();
    }else{
        mapsel.hide();
        maplabel0.hide();
        buttonmapcolor.hide();
    }
    if(boolpointing){
        pointingslider.show();
        sliderlabel1.show();
        errorslider.show();
        sliderlabel2.show();
    }else{
        pointingslider.hide();
        sliderlabel1.hide();
        errorslider.hide();
        sliderlabel2.hide();
    }
    if(mouseX<mapmax){
        triallabel3.show();
        for(i = 0; i<trialRows;i++){
            checktriallist[i].show();
        }
        checkicon.show();
        checktrajec.show();
        checkrotate.show();
        buttontrial.show();
    }else{
        triallabel3.hide();
        for(i = 0; i<trialRows;i++){
            checktriallist[i].hide();
        }
        checkicon.hide();
        checktrajec.hide();
        checkrotate.hide();
        buttontrial.hide();
    }
    
}