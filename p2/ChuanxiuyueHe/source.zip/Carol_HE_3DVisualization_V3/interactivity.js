function autoRotation(){
    ang1=radians(angle1);
    rotate(ang1,[1,1,0]);
    angle1=angle1+0.7;
}
function NovelObs(){
    rotate(-PI/2,[0,0,1]); 
}

function DvdObs(){
    rotate(-PI/2,[0,0,1]);
    rotate(PI,[0,1,0]);
}
function seeNovelModel(){
    rotate(-PI/2,[0,1,0]);
    rotate(-PI/2,[1,0,0]);
}
function seeDvdModel(){
    rotate(PI/2,[0,1,0]);
    rotate(PI/2,[1,0,0]);
}
