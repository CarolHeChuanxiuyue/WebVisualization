function drawLabels(){
    
    
    if(drawyear){
        //main year
        push();
        textFont(Gotham);
        textSize(15);
        textAlign(CENTER, CENTER);
        translate(0,-1*mapmax-cellsize,0);
        fill(colorcurrent.year);
        text(startYear,0,0);
        text(startYear+yearRange,0,2*mapmax+2* cellsize);
        pop();
        
        //years on model layers
        for (var i = 0; i<yearRange;i++){
            push();
            textFont(Gotham);
            textSize(8);
            textAlign(LEFT, LEFT);
            translate(0,-1*mapmax+i*cellsize,-mapmax);
            rotate(PI/2,[0,0,1]);
            rotate(PI/2,[1,0,0]);
            fill(colorcurrent.novelt);
            text(startYear+i,0,0);
            pop();
        }
        for (var i = 0; i<yearRange;i++){
            push();
            textFont(Gotham);
            textSize(8);
            textAlign(LEFT, LEFT);
            translate(0,-1*mapmax+i*cellsize,mapmax);
            rotate(PI,[0,1,0]);
            rotate(PI/2,[1,0,0]);
            rotate(PI/2,[0,1,0]);
            fill(colorcurrent.dvdt);
            text(startYear+i,0,0);
            pop();
        
        }
        
    }

    if(drawmodeltitle){
        //TS model of the Novel checkouts
   
        push();
        fill(colorcurrent.novelr);
        textFont(Gotham);
        textSize(10);
        textAlign(CENTER, CENTER);
        translate(0,0,-mapmax-cellsize/2);
        rotate(PI/2,[0,0,1]);
        rotate(PI/2,[1,0,0]);
        text('Time Series Model of monthly chekcouts of the novels',0,0);
        pop();
    
        //TS model of the DVD checkouts
        push();
        fill(colorcurrent.dvdr);
        textFont(Gotham);
        textSize(10);
        textAlign(CENTER, CENTER);
        translate(0,0,mapmax+cellsize/2);
        rotate(PI,[0,1,0]);
        rotate(PI/2,[1,0,0]);
        rotate(PI/2,[0,1,0]);
        text('Time Series Model of monthly checkouts of the DVDs',0,0);
        pop();
    }
    
    
    if(drawobservetitle){
        push();
        fill(colorcurrent.novelt);
        textFont(Gotham);
        textSize(10);
        textAlign(CENTER, CENTER);
        translate(mapmax-2*cellsize,0,0);
        rotate(PI/2,[0,0,1]);
        text('Monthly Checkouts of the Novel',0,0);
        textSize(8);
        text('Range: '+parseFloat(novelmin*100).toFixed(3)+'%-'
             +parseFloat(novelmax*100).toFixed(3)+'%'+' out of total montly novel checkouts',0,20);
        pop();
        //Title for dvd observations
        push();
        fill(colorcurrent.dvdt);
        textFont(Gotham);
        textSize(10);
        textAlign(CENTER, CENTER);
        translate(-mapmax-cellsize,0,0);
        rotate(-PI/2,[0,0,1]);
        rotate(-PI,[0,1,0]);
        text('Monthly Checkouts of the Dvds',0,0);
        textSize(8);
        text('Range: '+parseFloat(dvdmin*100).toFixed(3)+'%-'+parseFloat(dvdmax*100).toFixed(3)+'%'+' out of total montly DVDs checkouts',0,20);
        pop();
    }

    

}

