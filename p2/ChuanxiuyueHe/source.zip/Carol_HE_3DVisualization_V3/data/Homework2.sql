SELECT 
    EXTRACT(YEAR_MONTH FROM cout) AS year_months,
    COUNT(*) AS checkouts
FROM
    spl_2016.outraw
WHERE
    itemtype = 'acdvd' and EXTRACT(YEAR_MONTH FROM cout) != "202002"
GROUP BY EXTRACT(YEAR_MONTH FROM cout)
LIMIT 500;

SELECT 
    EXTRACT(YEAR_MONTH FROM cout) AS year_months,
    COUNT(*) AS checkouts
FROM
    spl_2016.outraw
WHERE
    itemtype = 'acbk'
        AND EXTRACT(YEAR_MONTH FROM cout) != '202002'
GROUP BY EXTRACT(YEAR_MONTH FROM cout)
LIMIT 500;

SELECT 
    EXTRACT(YEAR_MONTH FROM cout) AS year_months,
    COUNT(CASE
        WHEN
            (LOWER(title) IN ('game of thrones' , 'game of thrones the graphic novel Volume 1',
                'game of thrones the graphic novel Volume 2',
                'game of thrones the graphic novel Volume 3',
                'game of thrones the graphic novel Volume 4')
                AND itemtype = 'acbk')
        THEN
            1
    END) AS novel1,
    COUNT(CASE
        WHEN
            (LOWER(title) IN ('clash of kings' , 'clash of kings the graphic novel Volume 1',
                'clash of kings the graphic novel Volume 2',
                'clash of kings book two of A song of ice and fire')
                AND itemtype = 'acbk')
        THEN
            1
    END) AS novel2,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'storm of swords'
                AND itemtype = 'acbk')
        THEN
            1
    END) AS novel3,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'feast for crows'
                AND itemtype = 'acbk')
        THEN
            1
    END) AS novel4,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'dance with dragons'
                AND itemtype = 'acbk')
        THEN
            1
    END) AS novel5,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete first season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season1,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete second season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season2,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete third season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season3,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete fourth season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season4,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete fifth season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season5,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete sixth season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season6,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete seventh season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season7,
    COUNT(CASE
        WHEN
            (LOWER(title) = 'game of thrones the complete eighth season'
                AND itemtype = 'acdvd')
        THEN
            1
    END) AS season8
FROM
    spl_2016.outraw
WHERE
    EXTRACT(YEAR_MONTH FROM cout) != '202002'
GROUP BY EXTRACT(YEAR_MONTH FROM cout)
LIMIT 500;