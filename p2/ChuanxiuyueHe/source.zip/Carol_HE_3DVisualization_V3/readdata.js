function readdata(){
    //Get the number of rows of the data
    numRows= table.getRowCount();
    //Get the number of columns of the data
    numCols= table.getColumnCount(); 
    //print("Rows: " + numRows + " , Columns: " + numCols);  
    
    // retrieve data from table
    for(var i = 0; i <numRows; i++){
        dataMatrix[i]= []; //create nested array
        for(var j = 0; j < numCols-2; j++){
            if(table.get(i,j)==NaN){
                dataMatrix[i][j]=NaN;
            }else{dataMatrix[i][j]=table.getNum(i,j+2);}
        }
    }
    
    //find Max and Min for novels and books
    for (i=0; i<numRows;i++){
        if(dataMatrix[i][0]<novelmin){
            novelmin=dataMatrix[i][0];
        }
        if(dataMatrix[i][0]>novelmax){
            novelmax=dataMatrix[i][0];
        }
        if(dataMatrix[i][4]<dvdmin){
            dvdmin=dataMatrix[i][4];
        }
        if(dataMatrix[i][4]>dvdmax){
            dvdmax=dataMatrix[i][4];
        }
    }
    //print("novelmin%: "+novelmin+", novelmax%:"+novelmax);
    
    //map seasonal data to coordinates
    seasonal_coord();
    
    //map trend and random data to coordinates
    trend_coord();

}

function seasonal_coord(){
    for (var i=0; i<numRows;i++){
        season_1[i]=map(dataMatrix[i][1],novelmin,novelmax,mapmin,mapmax);
        season_2[i]=map(dataMatrix[i][5],dvdmin,dvdmax,mapmin,mapmax);
        season_3[i]=map(dataMatrix[i][1],dvdmin,dvdmax,mapmin,mapmax);
        season_xRot[i]= (i%12===0)?0:(PI*(i%12))/12.0;
        season_xNov[i]=sin(season_xRot[i])*season_1[i];
        season_zNov[i]=cos(season_xRot[i])*season_1[i];
        season_xDvd[i]=-sin(season_xRot[i])*season_2[i];
        season_zDvd[i]=-cos(season_xRot[i])*season_2[i];
    }
    
    //find maximum seasonal data
    for (i=0; i<numRows;i++){
        if(season_1[i]>novelseasonmax){
            novelseasonmax=season_1[i];
        }
        if(season_2[i]>dvdseasonmax){
            dvdseasonmax=season_2[i];
        }
    }
}

function trend_coord(){
    for (var i=0; i<numRows-12;i++){
        trendNovel[i]=map(dataMatrix[i+6][2],novelmin,novelmax,mapmin,mapmax);
        trendDvd[i]=map(dataMatrix[i+6][6],dvdmin,dvdmax,mapmin,mapmax);
        //print("trendNovel "+i+" is: "+trendNovel[i]);
        scalar_novel[i]=map(Math.abs(dataMatrix[i+6][3]),novelmin,novelmax,mapmin,mapmax);
        scalar_dvd[i]=map(Math.abs(dataMatrix[i+6][7]),dvdmin,dvdmax,mapmin,mapmax);
    }
    
}