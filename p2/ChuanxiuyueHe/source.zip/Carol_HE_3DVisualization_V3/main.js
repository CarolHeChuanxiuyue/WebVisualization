//data variables
let table;
let dataMatrix = [];
let numRows, numCols;
let novelmin=1,novelmax=0;
let dvdmin=1,dvdmax=0;
let startYear = 2010;
let yearRange=10;
var trendNovel = [];
var trendDvd = [];
let season_1 = [];
let season_2 = [];
let season_3 = [];
let novelseasonmax=0,dvdseasonmax=0;

//set coordinates
let mapmin=0;
let mapmax=250;
let season_xRot = [];
let season_xNov = [], season_zNov = [];
let season_xDvd = [], season_zDvd = [];
let cellsize = 2*mapmax/yearRange;
let xPos=0;

//set animation parameters
let angle1=0;
let angle2=0;
let ang1;
let ang2;
let scalar_novel = [];
let scalar_dvd = [];

//colorsolution
let colorpool = [
    {year: [166,194,165], novelo: [212,102,108], novelt: [255, 162, 162], novelr: [253, 197, 197], novels: [255, 162, 162], dvdo: [246, 229, 208], dvdt: [222, 235, 241], dvdr: [234,232,224], dvds: [234,232,224]},
    {year: [252,240,233], novelo: [250,236,229], novelt: [246,224,214], novelr: [252,240,233], novels: [246,224,214], dvdo: [103,127,163], dvdt: [168,189,214], dvdr: [211,219,230], dvds: [168,189,214]},
    {year: [205,173,130], novelo: [215, 174, 150], novelt: [173, 126, 114], novelr: [179, 162, 165], novels: [179, 162, 165], dvdo: [220, 206, 217], dvdt: [236, 222, 232], dvdr: [250, 236, 243], dvds: [250, 236, 243]}
];
let colorcurrent=colorpool[0];

//Interaction
let autorotate
let seenovelmodel
let seedvdmodel
let seenovelobs
let seedvdobs
let drawrandompoint
let drawmodeltitle
let drawobservetitle
let drawyear
let buttoncolor
let checkrandom
let checkmodeltitle
let checkobservetitle
let checkyear

//instructions
let interac_instruc

function preload(){
    table = loadTable("data/decompose_model.csv",'utcsv','header');
    Gotham = loadFont('data/Gotham-Bold.otf');
    DIN = loadFont('data/DIN.otf');
}
function setup(){
    //set up 3D canvas
    createCanvas(windowWidth,windowHeight,WEBGL);

    
    //Set of the starting perspective:perspective([fovy], [aspect], [near], [far])
    perspective(PI/3.0 , width / height, 0.1, 5000);
    readdata();
    autorotate=false;
    seenovelmodel=false;
    seedvdmodel=false;
    seenobelobs=false;
    seedvdobs=false;
    drawrandompoint=false;
    drawmodeltitle=false;
    drawobservetitle=false;
    drawyear=false;
    

    buttoncolor = createButton('Change Color Solution');
    buttoncolor.style('background-color',color(200,255,255));
    buttoncolor.style('color',color(0,0,15));
    buttoncolor.position(0,1.8*mapmax);
    buttoncolor.mousePressed(changecolorsolution);
    checkrandom = createCheckbox('moving random dots',false);
    checkrandom.position(0,1.8*mapmax+cellsize/2);
    checkrandom.style('color',color(200,255,255));
    checkrandom.changed(drawpoint);
    checkobservetitle = createCheckbox('Show labels of the observations',false);
    checkobservetitle.position(0,1.8*mapmax+cellsize);
    checkobservetitle.style('color',color(200,255,255));
    checkobservetitle.changed(drawobtitle);
    checkmodeltitle = createCheckbox('Show labels of TS models',false);
    checkmodeltitle.position(0,1.8*mapmax+3*cellsize/2);
    checkmodeltitle.style('color',color(200,255,255));
    checkmodeltitle.changed(drawmotitle);
    checkyear = createCheckbox('Show years',false);
    checkyear.position(0,1.8*mapmax+2*cellsize);
    checkyear.style('color',color(200,255,255));
    checkyear.changed(drawye);
    
    interac_instruc = createP('Press button \'a\' to turn on rotation <br/> repress button \'a\' to stop roation <br/> Perspective of monthly checkouts of A Sing of Ice and Fire: \n Press button \'s\' <br/> Perspective of monthly checkouts of the DVDs: \n Press button \'d\ <br/> Perspective of TS model of the novels checkouts: \n Press button \'f\' <br/> Perspective of TS model of the DVDs checkouts: \n Press button \'g\' ');
    interac_instruc.position(0,1.8*mapmax+5*cellsize/2);
    interac_instruc.style('color',color(200,255,255));
    
    

}
function draw(){
    background(0);
    
    if(mouseX<mapmax){
        interac_instruc.show();
    }else{interac_instruc.hide();}

    //instructions
    /*push();
    textFont(DIN);
    textSize(15);
    textAlign(LEFT, LEFT);
    translate(-2.2*mapmax,-1.5*mapmax,0);
    fill(255,255,255,125);
    text('Press button \'a\' to turn on rotation',0,cellsize/2);
    text('repress button \'a\' to stop roation',0,cellsize);
    text('For monthly checkouts of A Sing of Ice and Fire: \n Press button \'s\'',0,2*cellsize);
    text('For monthly checkouts of the DVDs: \n Press button \'d\'',0,3*cellsize);
    text('For TS model of the novels checkouts: \n Press button \'f\'',0,4*cellsize);
    text('For TS model of the DVDs checkouts: \n Press button \'g\'',0,5*cellsize);
    pop();*/
    
    
    orbitControl();
    lights();

    
    if(autorotate){
        autoRotation();
    }
    if(seedvdmodel){
        seeDvdModel();
    }
    if(seenovelmodel){
        seeNovelModel();
    }
    if(seenobelobs){
        NovelObs();
    }
    if(seedvdobs){
        DvdObs();
    }
    
    
    drawData();
    drawLabels();
    

}
function keyTyped() {
    if (key == 'a') {
        if(autorotate){autorotate=false;}
        else{autorotate=true;}}
    if(key=='s'){
        if(seenobelobs){seenobelobs=false;}
        else{seenobelobs=true;
             seedvdobs=false;
             seenovelmodel=false;
             seedvdmodel=false;
            }}
    if(key=='d'){
        if(seedvdobs){seedvdobs=false;}
        else{seenobelobs=false;
            seedvdobs=true;
            seenovelmodel=false;
            seedvdmodel=false;}}
    if(key == 'f'){
        if(seenovelmodel){seenovelmodel=false;}
        else{seenobelobs=false;
             seedvdobs=false;
            seenovelmodel=true;
            seedvdmodel=false;}}
    if(key == 'g'){
        if(seedvdmodel){seedvdmodel=false;}
        else{seenobelobs=false;
             seedvdobs=false;
             seenovelmodel=false;
             seedvdmodel=true;}}
}
function changecolorsolution(){
    if(colorcurrent==colorpool[0]){
        colorcurrent=colorpool[1];
    }else if(colorcurrent==colorpool[1]){
        colorcurrent=colorpool[2];
    }else{colorcurrent=colorpool[0];}
}

function drawpoint(){
    if(drawrandompoint){
        drawrandompoint=false;
    }else{drawrandompoint=true;}
}
function drawobtitle(){
    if(drawobservetitle){
        drawobservetitle=false;
    }else{drawobservetitle=true;}
}
function drawmotitle(){
    if(drawmodeltitle){
        drawmodeltitle=false;
    }else{drawmodeltitle=true;}
}
function drawye(){
    if(drawyear){
        drawyear=false;
    }else{drawyear=true;}
}