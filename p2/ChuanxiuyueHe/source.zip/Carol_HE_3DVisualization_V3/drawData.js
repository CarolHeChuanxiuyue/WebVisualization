
function drawObs(){
    //draw observations
    for (var i=0; i<numRows; i++){
        //draw novel%
        xPos = map(dataMatrix[i][0],dvdmin,dvdmax,mapmin,mapmax);
        push();
        //stroke(17+(i*238/numRows),91+(i*156/numRows),59+(i*150/numRows));
        //stroke(241-(i*224/numRows),197-(i*106/numRows),210-(i*141/numRows));
        stroke(colorcurrent.novelo);
        strokeWeight(5);
        //translate(xPos,-250+i*4,0);
        line(xPos+novelseasonmax+10,-1*mapmax+i*4,0,season_3[i]+novelseasonmax+10,-1*mapmax+i*4,0);
        pop();
        
        //draw dvd%
        if(dataMatrix[i][4]!=0){
            xPos = map(dataMatrix[i][4],dvdmin,dvdmax,mapmin,mapmax);
            push();
            //stroke(255*i/numRows,150,26);
            //stroke(17+(i*238/numRows),91+(i*156/numRows),59+(i*150/numRows));
            //stroke(159-(i*142/numRows),57+(i*14/numRows),88-(i*29/numRows));
            stroke(colorcurrent.dvdo);
            strokeWeight(5);
            //translate(-xPos,-250+i*4,0);
            line(-xPos-dvdseasonmax-(mapmax/25),-1*mapmax+i*4,0,-season_2[i]-(mapmax/25),-1*mapmax+i*4,0);
            pop();
        }

    }
}
function drawTrend(){
    //Main Trend of novels;
    push();
    rotate(PI/2.0,[0,1,0])
    stroke(colorcurrent.novelt);
    strokeWeight(2);
    beginShape(LINES);
    for(var k=0; k<numRows-12; k++){
        vertex(trendNovel[k],-1*mapmax+(k+6)*4,0);
    }
    vertex(trendNovel[0],-1*mapmax+6*4,0);
    endShape(CLOSE);
    pop();
    
    //Main Trend of Dvds;
    push();
    rotate(-PI/2.0,[0,1,0])
    stroke(colorcurrent.dvdt);
    strokeWeight(2);
    //fill(200,25,16);
    //noStroke();
    beginShape(LINES);
    for(var k=0; k<numRows-12; k++){
        vertex(trendDvd[k],-250+(k+6)*4,0);
    }
    vertex(trendDvd[0],-250+6*4,0);
    endShape(CLOSE);
    pop();
    
}
function drawRandom(){
    angle2=angle2+7;
    ang2=radians(angle2);
    for (var i=0; i<numRows-12; i++){
        //novel random
        push();
        //stroke(255*i/numRows,150,26);
        //stroke(241-(i*224/numRows),197-(i*106/numRows),210-(i*141/numRows));
        stroke(colorcurrent.novelr);
        strokeWeight(5);
        rotate(PI/2.0,[0,1,0])
        translate(trendNovel[i]+scalar_novel[i]*Math.sin(ang2),-250+(i+6)*4,0);
        point(0);
        pop();
        
        //dvd random
        push();
        //stroke(255*i/numRows,150,26);
        //stroke(159-(i*142/numRows),57+(i*14/numRows),88-(i*29/numRows));
        stroke(colorcurrent.dvdr);
        strokeWeight(5);
        rotate(-PI/2.0,[0,1,0])
        translate(trendDvd[i]+scalar_dvd[i]*Math.sin(ang2),-250+(i+6)*4,0);
        point(0);
        pop();
    }
}
function drawRandomRange(){

    //novel random
    push();
    stroke(colorcurrent.novelr);
    strokeWeight(2);
    noFill();
    beginShape();
    for(var k=0; k<numRows-12; k++){
    vertex(0,-mapmax+4*(k+6),-trendNovel[k]-scalar_novel[k]);
    }
    endShape();
    beginShape();
    for(var k=0; k<numRows-12; k++){
    vertex(0,-mapmax+4*(k+6),-trendNovel[k]+scalar_novel[k]);
    }
    endShape();
    pop();
    
    //dvd random
    push();
    stroke(colorcurrent.dvdr);
    strokeWeight(2);
    noFill();
    beginShape();
    for(var k=0; k<numRows-12; k++){
    vertex(0,-mapmax+4*(k+6),trendDvd[k]+scalar_dvd[k]);
    }
    endShape();
    beginShape();
    for(var k=0; k<numRows-12; k++){
    vertex(0,-mapmax+4*(k+6),trendDvd[k]-scalar_dvd[k]);
    }
    endShape();
    pop();
}
function drawSeason(){
    for(var i=1; i<numRows; i++){
        //xRot = (i%12===0)?0:(PI*(i%12))/12.0;
        //shapeX[i]=sin(xRot)*zPos;
        //shapeY[i]=cos(xRot)*zPos;
        push();
        stroke(colorcurrent.novels);
        strokeWeight(5);
        //rotate(xRot,[0,1,0]);
        //translate(0,(i/12)*50-250,season_1[i]);
        //line(sin(season_xRot[i-1])*season_1[i-1],((i-1)/12)*50-250,cos(season_xRot[i-1])*season_1[i-1],sin(xRot)*season_1[i],(i/12)*50-250,cos(xRot)*season_1[i]);
        //print(parseInt(i/12));
        line(season_xNov[i-1],((i-1)/12)*(mapmax/5)-mapmax,season_zNov[i-1],season_xNov[i],(i/12)*(mapmax/5)-mapmax,season_zNov[i])
        //point(0);
        //pop();
        //xRot = (i%12===0)?0:(-PI*(i%12))/12.0;
        //shapeX[i]=sin(xRot)*zPos;
        //shapeY[i]=cos(xRot)*zPos;
        //push();
        stroke(colorcurrent.dvds);
        strokeWeight(5);
        //rotate(xRot,[0,1,0]);
        //translate(0,(i/12)*50-250,season_2[i]);
        //line(-sin(xRot)*season_2[i-1],((i-1)/12)*50-250,-cos(xRot)*season_2[i-1],-sin(xRot)*season_2[i],(i/12)*50-250,-cos(xRot)*season_2[i]);
        //print(parseInt(i/12));
        line(season_xDvd[i-1],((i-1)/12)*(mapmax/5)-mapmax,season_zDvd[i-1],season_xDvd[i],(i/12)*(mapmax/5)-mapmax,season_zDvd[i])
        //point(0);
        pop();
    }
}

function drawData(){
    
    push();
    fill(119,22,51);
    noStroke();
    cylinder(1, 2*mapmax);
    pop();
    
    drawObs();
    drawTrend();
    if(drawrandompoint){
        drawRandom();
    }
    drawRandomRange();
    drawSeason();
    

}